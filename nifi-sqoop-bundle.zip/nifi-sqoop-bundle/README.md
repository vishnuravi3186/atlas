# nifi-sqoop-bundle
NiFi Sqoop Import/Export bundle 
